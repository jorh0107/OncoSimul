
library(OncoSimulR) 

# Configuración de los parámetros iniciales
pop_size <- 10000   # Tamaño inicial de la población
time_limit <- 1000  # Límite de tiempo para ejecutar la simulación
mutation_rate <- 1e-5 # Tasa estándar de mutación aplicada en las simulaciones

# Definir un modelo de poset con datos estructurados
fitness_map <- allFitnessEffects(
  data.frame(
    parent = c("Root", "A", "B", "C"),  # Relaciones jerárquicas de dependencia genética
    child = c("A", "B", "C", "D"),     # Cada gen hijo depende de su gen padre
    s = c(0.1, 0.05, -0.1, 0.2),           # Efectos selectivos: positivos o negativos
    sh = c(-0.9, -0.8, -0.7, -0.5),        # Efectos negativos en heterocigotos
    typeDep = c("MN", "MN", "MN", "SM")  # Tipos de dependencia: MN (mutaciones necesarias) o SM (sinergia mutacional)
  )
)

# Realizar una simulación con tasas de mutación específicas de genes
sim_result <- oncoSimulPop(
  Nindiv = 100,   # Número de replicados en la simulación
  fp = fitness_map, # Mapa de fitness previamente definido
  model = "McFL", # Modelo basado en McFarland
  initSize = pop_size, # Tamaño inicial de la población
  mu = c("A" = 1e-6, "B" = 1e-7, "C" = 1e-5, "D" = 1e-4), # Tasas de mutación específicas por gen
  finalTime = time_limit, # Tiempo máximo de la simulación
  detectionSize = 1e8, # Tamaño de la población que detiene la simulación
  keepEvery = 10, # Intervalos para almacenar datos durante la simulación,
  mc.cores = 4
  
)

# Visualizar los resultados de la simulación
plot(sim_result, addtot = TRUE, lwdClone = 0.6, log = "") # Grafica los tamaños de los clones en el tiempo
summary(sim_result) # Resumen estadístico de la simulación

# Generar un gráfico de las restricciones genéticas definidas en el modelo
# Este gráfico muestra cómo los genes están relacionados entre sí
genetic_plot <- plot(fitness_map)

# Agregar intervención terapéutica basada en la frecuencia dependiente
# Modelo que ajusta las tasas de nacimiento según las frecuencias relativas de genotipos
genofit <- data.frame(
  A = c(0, 1, 0, 1), # Genotipo A presente o ausente
  B = c(0, 0, 1, 1), # Genotipo B presente o ausente
  Birth = c(          # Tasa de nacimiento dependiente de frecuencias
    "3 + 5*f_",             # Base de 3 con un incremento proporcional a f_
    "3 + 5*(f_ + f_A)",     # Base ajustada por la frecuencia de A
    "3 + 5*(f_ + f_B)",     # Base ajustada por la frecuencia de B
    "5 + 6*(f_ + f_A_B)"    # Base ajustada por la interacción de A y B
  )
)

# Configurar efectos de fitness dependientes de la frecuencia
fd_fitness <- allFitnessEffects(genotFitness = genofit, frequencyDependentBirth = TRUE)

# Simular una población individual con dependencia de frecuencia
osi <- oncoSimulIndiv(
  fd_fitness,            # Modelo de fitness dependiente de frecuencia
  model = "McFL",       # Modelo basado en McFarland
  onlyCancer = FALSE,    # Permitir simulación sin restricciones a cáncer
  finalTime = 200,       # Tiempo final para esta simulación
  mu = c("A" = 1e-6, "B" = 1e-8), # Tasas de mutación específicas
  initSize = 5000        # Tamaño inicial de la población
)

# Visualizar los resultados de la simulación con dependencia de frecuencia
plot(osi, show = "genotypes", type = "line") # Grafica las frecuencias de los genotipos en el tiempo


summary(sim_result)
