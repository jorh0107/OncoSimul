# Cargar librería
library(OncoSimulR)

# Configuración inicial
pop_size <- 10000     # Tamaño inicial de la población
time_limit <- 1000    # Tiempo máximo para la simulación
num_simulations <- 100 # Número de replicados

# Definir el mapa genético con dependencias y efectos selectivos
fitness_map <- allFitnessEffects(
  data.frame(
    parent = c("Root", "Root", "Root", "B", "A"),
    child = c("A", "B", "C", "D", "D"),
    s = c(0.1, 0.05, -0.1, 0.2, 0.2), # Efectos selectivos para cada gen
    sh = c(-0.2, -0.1, -0.3, -0.1, -0.1), # Efectos negativos en heterocigotos
    typeDep = c("MN", "MN", "MN", "SM", "SM")
  )
)

# Verificar el modelo genético
plot(fitness_map)

# Definir las tasas de mutación por gen
# Debe coincidir exactamente con los genes definidos en fitness_map
mu <- c("A" = 1e-6, "B" = 1e-7, "C" = 1e-5, "D" = 1e-4)

# Revisar que las tasas de mutación coincidan con los genes definidos
if (!all(names(mu) %in% unique(c("A", "B", "C", "D")))) {
  stop("Las tasas de mutación no coinciden con los genes definidos en el mapa de fitness.")
}

# Configuración de la simulación
osi <- oncoSimulIndiv(
  fp = fitness_map,         # Mapa de fitness previamente definido
  model = "McFL",           # Modelo de McFarland
  finalTime = time_limit,   # Tiempo final de la simulación
  mu = mu,                  # Tasas de mutación por gen
  initSize = pop_size       # Tamaño inicial de la población
)

# Visualizar los resultados de la simulación
plot(osi, show = "genotypes", type = "line") # Gráfico de frecuencias de genotipos en el tiempo
summary(osi) # Resumen estadístico de la simulación
